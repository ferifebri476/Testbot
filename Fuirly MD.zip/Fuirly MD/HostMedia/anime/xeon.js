{
	"name": "Fuirly Botz Multi Device "
}